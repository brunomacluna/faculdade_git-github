# LTPI • Professor: Lucas A. Silveira
# Período: 2º. 2024 - Unidade 713/913 Sul - Turma: 2º SEM
# Curso: ADS DATA: 27/11/2024
# Aluno(a) : Bruno Machado Luna

# QUESTÃO 2 • valor: 3,0 pontos

# A. Somente as afirmações I e II estão corretas
# B. Somente as afirmações I, II e III estão corretas.
# C. Somente as afirmações II e IV estão corretas.
# D. Somente a afirmação IV está correta.

# Resposta: Letra B

# QUESTÃO 3 • valor: 3,0 pontos

# Resposta: 
# 1 - A
# 2 - B
# 3 - C